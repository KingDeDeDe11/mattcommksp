#If you want upload your language files,please seed it into my e-mail:amdyes_qwq@outloo.com OR langbaobao1015@163.com
#And don't forget write your name in your language files
like this"//<language> by <your name>"

## Translation Guide
If you want to help translate this mod, I greatly appreciate it! Follow this quick guide to get started.

### How to translate
To create a translation for your language, make a copy of the file *en-us.cfg* and name
them accordingly to your language:
* *es-es.cfg* for Spanish
* *es-mx.cfg* for Mexican Spanish
* *ja.cfg* for Japanese
* *ru.cfg* for Russian
* *zh-cn.cfg* for Simplified Chinese

### What not to translate
There are some characters that should not be translated into another language and be kept in the files as is
1. the tags should not be replaced. Instead the tags in the new language should be appended.
2. control sequences like '\n', '\t' or similar.
3. HTML Tags like &lt;b&gt;...&lt;/b&gt;, &lt;i&gt;...&lt;/i&gt; or similar  

## Translation Credits
*AMDYes_QwQ (English)
*AMDYes_QwQ (Chinese Simplified)